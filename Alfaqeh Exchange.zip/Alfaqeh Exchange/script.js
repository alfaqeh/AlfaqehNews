﻿const apiKey= "3e1aec2c0f0b5d46c748cbec"; // ضع مفتاح API هنا
const apiURL = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`;

const fromCurrency = document.getElementById("fromCurrency");
const toCurrency = document.getElementById("toCurrency");
const amount = document.getElementById("amount");
const result = document.getElementById("result");
const exchangeRateText = document.getElementById("exchangeRate");
const languageSelect = document.getElementById("languageSelect");
const title = document.getElementById("title");
const convertBtn = document.getElementById("convertBtn");

let exchangeRates = {};
let currentLanguage = "ar";
const cacheKey = "exchangeRates";
const cacheExpiryKey = "exchangeRatesExpiry";
const cacheDuration = 12 * 60 * 60 * 1000; // 12 ساعة بالمللي ثانية

// التحقق من وجود بيانات مخزنة محليًا وصلاحيتها
function loadCachedData() {
    const cachedData = localStorage.getItem(cacheKey);
    const cacheExpiry = localStorage.getItem(cacheExpiryKey);
    const now = new Date().getTime();

    if (cachedData && cacheExpiry && now < parseInt(cacheExpiry)) {
        console.log("تم تحميل البيانات من التخزين المحلي");
        exchangeRates = JSON.parse(cachedData);
        populateCurrencySelect();
    } else {
        fetchExchangeRates();
    }
}

// جلب أسعار الصرف من API وتحديث التخزين المحلي
function fetchExchangeRates() {
    fetch(apiURL)
        .then(response => response.json())
        .then(data => {
            exchangeRates = data.conversion_rates;
            localStorage.setItem(cacheKey, JSON.stringify(exchangeRates));
            localStorage.setItem(cacheExpiryKey, (new Date().getTime() + cacheDuration).toString());
            console.log("تم تحديث البيانات من API");
            populateCurrencySelect();
        })
        .catch(error => console.error("خطأ في جلب البيانات:", error));
}

// تعبئة القوائم بالعملات
function populateCurrencySelect() {
    fromCurrency.innerHTML = "";
    toCurrency.innerHTML = "";

    for (const currency in exchangeRates) {
        fromCurrency.innerHTML += `<option value="${currency}">${currency}</option>`;
        toCurrency.innerHTML += `<option value="${currency}">${currency}</option>`;
    }
    fromCurrency.value = "USD";
    toCurrency.value = "EUR";
}

// تحويل العملات
function convertCurrency() {
    const from = fromCurrency.value;
    const to = toCurrency.value;
    const amountValue = parseFloat(amount.value);

    if (isNaN(amountValue) || amountValue <= 0) {
        result.innerText = currentLanguage === "ar" ? "الرجاء إدخال مبلغ صحيح" : "Please enter a valid amount";
        return;
    }

    const conversionRate = exchangeRates[to] / exchangeRates[from];
    const convertedAmount = (amountValue * conversionRate).toFixed(2);

    result.innerText = `${amountValue} ${from} = ${convertedAmount} ${to}`;
    exchangeRateText.innerText = currentLanguage === "ar" 
        ? `سعر الصرف اليومي: 1 ${from} = ${conversionRate.toFixed(4)} ${to}`
        : `Exchange Rate: 1 ${from} = ${conversionRate.toFixed(4)} ${to}`;
}

// تغيير اللغة
function changeLanguage() {
    currentLanguage = languageSelect.value;

    if (currentLanguage === "ar") {
        title.innerText = "محول العملات";
        convertBtn.innerText = "تحويل";
        amount.placeholder = "المبلغ";
    } else {
        title.innerText = "Currency Converter";
        convertBtn.innerText = "Convert";
        amount.placeholder = "Amount";
    }
}

// تحميل البيانات عند بدء التشغيل
loadCachedData();

